#!/usr/bin/env bash

activator -jvm-debug 9997 -J-Xms128M -J-Xmx512m -J-server -Duser.timezone=UTC -Dconfig.file=conf/consumer.conf 'run 7776'
