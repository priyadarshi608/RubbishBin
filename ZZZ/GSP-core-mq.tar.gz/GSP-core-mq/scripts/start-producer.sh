#!/usr/bin/env bash

#activator -jvm-debug 9997 -J-Xms512M -J-Xmx64000m -J-server -Duser.timezone=UTC -Dlogger.resource=debug.xml -Dconfig.file=conf/producer.conf 'run 7776'
activator -jvm-debug 9997 -J-Xms32m -J-Xmx128m -J-server -Duser.timezone=UTC -Dconfig.file=conf/producer.conf 'run 7776'
