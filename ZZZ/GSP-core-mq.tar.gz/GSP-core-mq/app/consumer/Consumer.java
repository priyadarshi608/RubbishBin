package consumer;

/**
 * Created by shubham on 15/12/16.
 */
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.io.IOException;
import java.util.*;

import play.Logger;

import services.*;
import play.libs.ws.WSClient;

class Consumer implements Runnable {
    private Topic topic;
    private int partition;
    private Properties consumerProperties;
    private KafkaConsumer<String, String> consumer;
    private final RestMethodsCaller restMethodsCaller;

    public Consumer(Topic topic,
                    int partition,
                    Properties properties,
                    WSClient wsClient,
                    RestMethodsCaller restMethodsCaller) {
        this.topic = topic;
        this.partition = partition;
        this.consumerProperties = properties;
        this.restMethodsCaller = restMethodsCaller;
        consumer = new KafkaConsumer<>(consumerProperties);
    }

    @Override
    public void run() {
        ObjectMapper mapper = new ObjectMapper();

        consumer.subscribe(Arrays.asList(topic.toString()));

        boolean haveData = true;
        while (haveData) {
            ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {

                JsonNode rootJson = null;
                try {
                    rootJson = mapper.readTree(record.value());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                JsonNode headerJson = rootJson.get("header");
                Map<String, String> headerMap = mapper.convertValue(headerJson, Map.class);

                JsonNode paramJson = rootJson.get("param");
                Map<String, String> paramMap = mapper.convertValue(paramJson, Map.class);

                JsonNode bodyJson = null;
                String body = rootJson.get("body").toString();
                if (body != "null")
                    bodyJson = rootJson.get("body");

                restMethodsCaller.call(topic, headerMap, paramMap, bodyJson, rootJson);
            }
            consumer.commitSync();
        }
    }
}
