package consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.Inject;
import play.Configuration;
import play.Logger;
import services.GSPRESTService;
import utils.ConfigMaps;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by shubham on 26/12/16.
 */
public class RestMethodsCaller {
    private final GSPRESTService gsprestService;
    private final ConfigMaps configMaps;
    Map<Topic, RestMethods> topic_method_map = new HashMap<>();

    @Inject
    RestMethodsCaller(GSPRESTService gsprestService,
                      ConfigMaps configMaps) {
        this.gsprestService = gsprestService;
        this.configMaps = configMaps;
    }

    public void call(Topic topic, Map<String, String> headerMap, Map<String, String> paramMap, JsonNode bodyJson, JsonNode request) {
        RestMethods restMethod = configMaps.getTopic_to_RestMethods_Map().get(topic);
        if (restMethod == RestMethods.put)
            gsprestService.put(topic, headerMap, bodyJson, request);
        else if (restMethod == RestMethods.post)
            gsprestService.post(topic, headerMap, bodyJson, request);
        else if (restMethod == RestMethods.get)
            gsprestService.get(topic, headerMap, paramMap, request);
    }
}
