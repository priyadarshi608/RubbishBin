package consumer;

/**
 * Created by shubham on 20/1/17.
 */
public enum RestMethods {
    get,
    put,
    post;
}
