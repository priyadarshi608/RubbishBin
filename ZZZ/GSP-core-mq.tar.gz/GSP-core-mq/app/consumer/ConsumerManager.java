package consumer;

/**
 * Created by shubham on 15/12/16.
 */
import com.google.inject.*;
import play.Configuration;
import play.Logger;

import java.util.Map;
import java.util.Properties;

import play.libs.ws.WSClient;
import utils.ConfigMaps;

@Singleton
public class ConsumerManager {
    private final Configuration configuration;
    private final WSClient wsClient;
    private final RestMethodsCaller restMethodsCaller;
    private final ConfigMaps configMaps;
    private final int NUMBER_OF_TOPICS;
    private final Thread[][] topicThreads;
    private final Thread[][] transactionLoggerThreads;
    private ConsumerLifeCycleManager manager;

    @Inject
    public ConsumerManager(Configuration configuration,
                           WSClient wsClient,
                           RestMethodsCaller restMethodsCaller,
                           ConfigMaps configMaps) {
        this.configuration = configuration;
        this.wsClient = wsClient;
        this.restMethodsCaller = restMethodsCaller;
        this.configMaps = configMaps;
        NUMBER_OF_TOPICS = Topic.values().length;
        topicThreads = new Thread[NUMBER_OF_TOPICS][];
        transactionLoggerThreads = new Thread[NUMBER_OF_TOPICS][];
        String actor = configuration.getString("kafka.actor").toString();
        if(!(actor.equals("producer"))) {
            manager = new ConsumerLifeCycleManager(configMaps);
            manager.start();
        }
    }

    private Properties consumerProperties() {
        Properties prop = new Properties();
        Configuration consumer_conf = configuration.getConfig("kafka_consumer");
        Map<String, Object> kafka_consumer_properties_map = consumer_conf.asMap();
        for (Map.Entry<String, Object> entry : kafka_consumer_properties_map.entrySet()) {
            prop.put(entry.getKey(), entry.getValue().toString());
        }
        return prop;
    }

    class ConsumerLifeCycleManager extends Thread {
        private final ConfigMaps configMaps;

        ConsumerLifeCycleManager(ConfigMaps configMaps) {
            this.configMaps = configMaps;
        }

        public void run() {
            int total_number_of_threads = 0;
            int topic_iterator = 0;
            for (Topic topic : Topic.values()) {
                // Putting default consumer properties in the properties object
                Properties consumerProperties = consumerProperties();

                // get the number of threads required for the topic specified
                int number_of_topic_partitions = configMaps.getTopic_to_NumberOfPartitions_Map().get(topic);

                topicThreads[topic_iterator] = new Thread[number_of_topic_partitions];
                transactionLoggerThreads[topic_iterator] = new Thread[number_of_topic_partitions];
                for (int i = 0; i < number_of_topic_partitions; i++) {
                    total_number_of_threads++;

                    Consumer consumer = new Consumer(topic,
                            i,
                            consumerProperties,
                            wsClient,
                            restMethodsCaller);
                    topicThreads[topic_iterator][i] = new Thread(consumer);
                    topicThreads[topic_iterator][i].start();
                }
            }
            Logger.debug("Total number of threads: " + total_number_of_threads);
        }
    }
}
