package utils;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import consumer.RestMethods;
import consumer.Topic;
import play.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by shubham on 22/1/17.
 */

@Singleton
public class ConfigMaps {
    private final Map<Topic, Integer> topic_to_NumberOfPartitions_Map = new HashMap<>();
    private final Map<Topic, RestMethods> topic_to_RestMethods_Map = new HashMap<>();

    @Inject
    public ConfigMaps(Configuration configuration) {
        Configuration all_topic_props = configuration.getConfig("topics");
        Map<String, Object> all_topic_properties_map = all_topic_props.asMap();
        for (Topic topic : Topic.values()) {
            Configuration topic_props = all_topic_props.getConfig(topic.toString());
            Map<String, Object> topic_properties_map = topic_props.asMap();

            // get the number of threads required for the topic specified
            int number_of_topic_partitions = (int) topic_properties_map.get("no_of_partitions");
            this.topic_to_NumberOfPartitions_Map.put(topic, number_of_topic_partitions);

            String method = topic_properties_map.get("method").toString();
            this.topic_to_RestMethods_Map.put(topic, RestMethods.valueOf(method));
        }
    }

    public Map<Topic, Integer> getTopic_to_NumberOfPartitions_Map() {
        return this.topic_to_NumberOfPartitions_Map;
    }

    public Map<Topic, RestMethods> getTopic_to_RestMethods_Map() {
        return this.topic_to_RestMethods_Map;
    }
}
