package services;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.ImplementedBy;
import com.google.inject.Inject;
import consumer.Topic;
import jdk.nashorn.internal.ir.ObjectNode;
import play.Configuration;
import play.Logger;
import play.libs.ws.WSClient;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;
import producer.ConfigurableProducer;

import javax.inject.Singleton;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

/**
 * Created by shubham on 25/12/16.
 */
@ImplementedBy(GSPRESTServiceImpl.class)
public interface GSPRESTService {
    CompletionStage<JsonNode> put(Topic topic, Map<String, String> headerMap, JsonNode body, JsonNode request);
    CompletionStage<JsonNode> post(Topic topic, Map<String, String> headerMap, JsonNode body, JsonNode request);
    CompletionStage<JsonNode> get(Topic topic, Map<String, String> headerMap, Map<String, String> paramMap, JsonNode request);
}
@Singleton
class GSPRESTServiceImpl implements GSPRESTService {
    private final WSClient wsClient;
    private final Configuration configuration;
    private String baseUrl = null;
    private final ConfigurableProducer configurableProducer;

    @Inject
    GSPRESTServiceImpl(WSClient wsClient,
                       Configuration configuration,
                       ConfigurableProducer configurableProducer) {
        this.wsClient = wsClient;
        this.configuration = configuration;
        this.configurableProducer = configurableProducer;
        configurableProducer.configure("async");
        configurableProducer.start();

        String txnid_type = configuration.getString("txnid_type").toString();
//        if(txnid_type.equals("asptxnid"))
        if(txnid_type.equals("txnid"))
            baseUrl = "http://localhost:8888/aspapi/v0.1/";
        else if(txnid_type.equals("gsptxnid"))
            baseUrl = "http://localhost:7777/gspapi/v0.1/";
    }

    public CompletionStage<JsonNode> put(Topic topic, Map<String, String> headerMap, JsonNode body, JsonNode request) {
        String urlOffset = topic.toString().replace('_', '/');
        WSRequest wsRequest = wsClient.url( baseUrl + urlOffset);
        for(Map.Entry<String, String> entry: headerMap.entrySet()) {
            wsRequest.setHeader(entry.getKey(), entry.getValue());
        }
        final CompletionStage<WSResponse> eventualResponse = wsRequest.put(body);
        return eventualResponse.thenApplyAsync(response -> {
            //requeIfEligible(response.asJson(), topic, request);
            Logger.debug(response.asJson().toString());
            return response.asJson();});
    }

    public CompletionStage<JsonNode> post(Topic topic, Map<String, String> headerMap, JsonNode body, JsonNode request) {
        String urlOffset = topic.toString().replace('_', '/');
        WSRequest wsRequest = wsClient.url( baseUrl + urlOffset);
        for(Map.Entry<String, String> entry: headerMap.entrySet()) {
            wsRequest.setHeader(entry.getKey(), entry.getValue());
        }
        final CompletionStage<WSResponse> eventualResponse = wsRequest.post(body);
        return eventualResponse.thenApplyAsync(response -> {
            //requeIfEligible(response.asJson(), topic, request);
            Logger.debug(response.asJson().toString());
            return response.asJson();});
    }

    public CompletionStage<JsonNode> get(Topic topic, Map<String, String> headerMap, Map<String, String> paramMap, JsonNode request) {
        String urlOffset = topic.toString().replace('_', '/');
        WSRequest wsRequest = wsClient.url( baseUrl + urlOffset);
        for(Map.Entry<String, String> entry: headerMap.entrySet()) {
            wsRequest.setHeader(entry.getKey(), entry.getValue());
        }
        for(Map.Entry<String, String> entry: paramMap.entrySet()) {
            wsRequest.setQueryParameter(entry.getKey(), entry.getValue());
        }
        final CompletionStage<WSResponse> eventualResponse = wsRequest.get();
        return eventualResponse.thenApplyAsync(response -> {
            //requeIfEligible(response.asJson(), topic, request);
            Logger.debug(response.asJson().toString());
            return response.asJson();});
    }

    private void requeIfEligible(JsonNode responseJson, Topic topic, JsonNode request) {
        String requestStr = request.toString();
        String numRetriesStr = request.get("number_of_tries").toString();
        int number_of_retries = Integer.parseInt(numRetriesStr.substring(1, numRetriesStr.length() - 1));
        if (eligibleForRetry(responseJson, number_of_retries)) {
            number_of_retries++;
            int endIndexOfFirstString = requestStr.indexOf("\"number_of_tries\":\"") + 19;
            int startIndexOfSecondString = requestStr.indexOf('"', endIndexOfFirstString);
            String newRequestStr = requestStr.substring(0, endIndexOfFirstString) + number_of_retries + requestStr.substring(startIndexOfSecondString, requestStr.length());
            try {
                this.configurableProducer.produce(
                        topic.toString(),
                        newRequestStr);
            } catch (ExecutionException | InterruptedException e) {
                Logger.error(e.toString());
            }
        }
    }

    private boolean eligibleForRetry(JsonNode responseJson, int numberOfRetries) {
        String statusString = responseJson.get("status_cd").toString();
        int status = Integer.parseInt(statusString.substring(1, statusString.length() - 1));
        if (status == 0 && numberOfRetries < 4)
            return true;
        else
            return false;
    }
}
