package services;

import com.google.inject.ImplementedBy;
import com.google.inject.Inject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import play.Configuration;
import play.Logger;

import org.json.simple.JSONObject;
import producer.ConfigurableProducer;
import producer.ConfigurableProducerImpl;

import javax.inject.Singleton;
import java.security.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.ExecutionException;

/**
 * Created by shubham on 15/12/16.
 */
@ImplementedBy(KafkaProducerServiceImpl.class)
public interface KafkaProducerService {
    String enqueInKafka(Map<String, String[]> header, Map<String, String[]> param, String body, String uri, String topic);
}

@Singleton
class KafkaProducerServiceImpl implements KafkaProducerService {
    private final Configuration configuration;
    private static KafkaProducer<String, String> producer = null;
    private final String txnid_type;
    private final ConfigurableProducer configurableProducer;
    private DateFormat dateFormat;

    @Inject
    KafkaProducerServiceImpl(Configuration configuration,
                             ConfigurableProducer configurableProducer) {
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
        this.configurableProducer = configurableProducer;
        configurableProducer.configure("async");
        configurableProducer.start();
        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
    }

    @Override
    public String enqueInKafka(Map<String, String[]> headers, Map<String, String[]> params, String body, String uri, String topic) {
        String txnid = UUID.randomUUID().toString();

        Map<String, String> header = new HashMap<String, String>();
        for (Map.Entry<String, String[]> entry: headers.entrySet()) {
            header.put(entry.getKey(), entry.getValue()[0]);
        }
        header.put(txnid_type, txnid);

        Map<String, String> param = new HashMap<String, String>();
        for (Map.Entry<String, String[]> entry: params.entrySet()) {
            param.put(entry.getKey(), entry.getValue()[0]);
        }

        JSONObject headerJson = new JSONObject();
        headerJson.putAll(header);
        String headerJsonStr = headerJson.toString();

        String paramJsonStr;
        JSONObject paramJson = new JSONObject();
        paramJson.putAll(param);
        paramJsonStr = paramJson.toString();

        String bodyJsonStr;
        if (body != null)
            bodyJsonStr = body;
        else
            bodyJsonStr = "null";

        Date date = new Date();
        String timestamp = dateFormat.format(date);

        try {
            String kakfaEntryString = String.format("{\"" + txnid_type + "\": \"%s\", \"header\": %s, \"param\": %s, \"body\": %s, \"uri\": \"%s\", \"number_of_tries\": \"" + 0 + "\", \"timestamp\": \"" + timestamp + "\"}",
                    txnid, headerJsonStr, paramJsonStr, bodyJsonStr, uri);
            this.configurableProducer.produce(
                    topic,
                    kakfaEntryString);
            return txnid;
        } catch (ExecutionException | InterruptedException e) {
            Logger.error(e.toString());
            return null;
        }
    }
}
