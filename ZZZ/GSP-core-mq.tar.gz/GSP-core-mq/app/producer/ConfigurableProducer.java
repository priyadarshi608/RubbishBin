package producer;

import com.google.inject.ImplementedBy;
import consumer.Topic;

import java.util.concurrent.ExecutionException;

/**
 * Created by shubham on 4/1/17.
 */
@ImplementedBy(ConfigurableProducerImpl.class)
public interface ConfigurableProducer {

    /**
     * create configuration for the producer
     * consult Kafka documentation for exact meaning of each configuration parameter
     */
    void configure(String sync);

    /* start the producer */
    void start();

    /**
     * create record and send to Kafka
     * because the key is null, data will be sent to a random partition.
     * exact behavior will be different depending on producer implementation
     */
    void produce(String topic, String s) throws ExecutionException, InterruptedException;

    void close();
}
