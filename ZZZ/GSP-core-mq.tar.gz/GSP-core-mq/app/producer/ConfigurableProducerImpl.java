package producer;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import consumer.Topic;
import org.apache.kafka.clients.producer.*;

import play.Configuration;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

/**
 * Created by shubham on 4/1/17.
 */
@Singleton
public class ConfigurableProducerImpl implements ConfigurableProducer {

    String sync;
    private Properties kafkaProps = new Properties();
    private Producer<String, String> producer;
    private final Configuration configuration;

    @Inject
    public ConfigurableProducerImpl(Configuration configuration) {
        this.configuration = configuration;
    }

    @Override
    public void configure(String sync) {
        this.sync = sync;
        Configuration producer_conf = configuration.getConfig("kafka_producer");
        Map<String, Object> kafka_producer_map = producer_conf.asMap();
        for (Map.Entry<String, Object> entry : kafka_producer_map.entrySet()) {
            kafkaProps.put(entry.getKey(), entry.getValue().toString());
        }
    }

    @Override
    public void start() {
        producer = new KafkaProducer<String, String>(kafkaProps);
    }

    @Override
    public void produce(String topic, String value) throws ExecutionException, InterruptedException {
        if (sync.equals("sync"))
            produceSync(topic, value);
        else if (sync.equals("async"))
            produceAsync(topic, value);
        else throw new IllegalArgumentException("Expected sync or async, got " + sync);

    }

    @Override
    public void close() {
        producer.close();
    }

    /* Produce a record and wait for server to reply. Throw an exception if something goes wrong */
    private void produceSync(String topic, String value) throws ExecutionException, InterruptedException {
        ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, value);
        producer.send(record).get();
    }

    /* Produce a record without waiting for server. This includes a callback that will print an error if something goes wrong */
    private void produceAsync(String topic, String value) {
        ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, value);
        producer.send(record, new ProducerCallback());
    }

    private class ProducerCallback implements Callback {

        @Override
        public void onCompletion(RecordMetadata recordMetadata, Exception e) {
            if (e != null) {
                System.out.println("Error producing to topic " + recordMetadata.topic());
                e.printStackTrace();
            }
        }
    }
}
