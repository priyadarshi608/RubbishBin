package  controllers;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import javax.inject.Inject;
import javax.inject.Singleton;

import play.Configuration;
import play.Logger;
import play.mvc.Controller;
import play.mvc.Result;
import services.KafkaProducerService;

@Singleton
public class RetGstr1Controller extends Controller {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public RetGstr1Controller(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    private Result result(String txnid) {
        Result result = null;
        if (txnid == null)
            result = ok("{\"status_cd\":\"0\"}");
        else
            result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return result;
    }

    public CompletionStage<Result> saveinvoices() {
//        Logger.info("in saveinvoices controller");
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr1_retsave");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> submit() {
//        Logger.info("in submit controller");
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr1_retsubmit");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2b() {
//        Logger.info("in b2b controller");
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2b");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2bamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2ba");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2clarge() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2cl");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2clargeamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2cla");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2cshsn() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2cs");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> b2csahsn() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_b2csa");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> creditdebitnotes() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_cdn");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> creditdebitnotesamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_cdna");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> nilrated() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_nil");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> exports() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_exp");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> exportamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_expa");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> advancetax() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_at");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> advancetaxamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_ata");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> taxpaid() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_txp");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> ecommerce() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_ecom");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> iraecom() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_iraecom");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> hsnsummary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_hsnsum");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> summary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_retsum");
        return CompletableFuture.completedFuture(result(txnid));
    }

    public CompletionStage<Result> returnstatus() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1_retstatus");
        return CompletableFuture.completedFuture(result(txnid));
    }
}
