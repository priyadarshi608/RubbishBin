package controllers;

import play.Configuration;
import play.mvc.Result;
import services.KafkaProducerService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.mvc.Controller.request;
import static play.mvc.Results.ok;

/**
 * Created by shubham on 26/12/16.
 */
public class LedController {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public LedController(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    public CompletionStage<Result> cashsummary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "ledgers_cashsummary");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> cashdetails() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "ledgers_cashdetails");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> itcsummary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "ledgers_itcsummary");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> itcdetails() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "ledgers_itcdetails");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> taxliability() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "ledgers_taxliability");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> utilizeitc() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "ledgers_utilizeitc");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> utilizecash() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "ledgers_utilizecash");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }
}
