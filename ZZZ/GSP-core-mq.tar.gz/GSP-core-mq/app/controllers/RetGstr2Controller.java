package controllers;

import play.Configuration;
import play.mvc.Result;
import services.KafkaProducerService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.mvc.Controller.request;
import static play.mvc.Results.ok;

/**
 * Created by shubham on 26/12/16.
 */
public class RetGstr2Controller {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public RetGstr2Controller(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    public CompletionStage<Result> b2b() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_b2b");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> b2bamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_b2ba");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> importgoods() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_impg");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> importgoodsamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_impga");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> importservices() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_imps");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> importservicesamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_impsa");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> creditdebitnotes() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_cdn");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> creditdebitnotesamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_cdna");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> nilrated() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_nil");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> isdcredit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_isd");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> tdscredit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_tds");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> tcscredit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_tcs");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> itcreceived() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_itc");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> taxliabunderreversecharge() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_txli");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> taxliabunderreversechargeamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_atxli");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> taxpaidunderreversecharge() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_txpd");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> itcreversal() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_itcrvsl");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> hsnsummary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_hsnsum");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> summary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_retsum");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> saveinvoices() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr2_retsave");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> submit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr2_retsubmit");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> returnstatus() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr2_retstatus");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }
}
