package controllers;

import play.Configuration;
import play.mvc.Result;
import services.KafkaProducerService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.mvc.Controller.request;
import static play.mvc.Results.ok;

/**
 * Created by shubham on 26/12/16.
 */
public class RetGstr1aController {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public RetGstr1aController(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    public CompletionStage<Result> b2b() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_b2b");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> b2bamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_b2ba");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> creditdebitnotes() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_cdn");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> creditdebitnotesamended() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_cdna");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> saveinvoices() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr1a_retsave");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> summary() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_retsum");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> submit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr1a_retsubmit");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> returnstatus() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr1a_retstatus");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }
}
