package controllers;

import play.Configuration;
import play.mvc.Result;
import services.KafkaProducerService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.mvc.Controller.request;
import static play.mvc.Results.ok;

/**
 * Created by shubham on 26/12/16.
 */
public class RetController {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public RetController(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    public CompletionStage<Result> trackarnstatus() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_general_trackarnstatus");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> viewreturns() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_general_viewreturns");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> advancetaxpaiddetails() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_general_advancetaxpaiddetails");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> tdstrack() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_general_tdstrack");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> partialitctrack() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_general_partialitctrack");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }
}
