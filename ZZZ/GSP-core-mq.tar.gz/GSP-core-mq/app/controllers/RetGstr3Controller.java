package controllers;

import play.Configuration;
import play.mvc.Result;
import services.KafkaProducerService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.mvc.Controller.request;
import static play.mvc.Results.ok;

/**
 * Created by shubham on 26/12/16.
 */
public class RetGstr3Controller {

    private final Configuration configuration;
    private final String txnid_type;
    private final KafkaProducerService kafkaProducerService;

    @Inject
    public RetGstr3Controller(final KafkaProducerService kafkaProducerService, Configuration configuration) {
        this.kafkaProducerService = kafkaProducerService;
        this.configuration = configuration;
        txnid_type = configuration.getString("txnid_type").toString();
    }

    public CompletionStage<Result> returndetail() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr3_retdet");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> saveinvoices() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr3_retsave");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> submit() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr3_retsubmit");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> generate() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                request().body().asJson().toString(),
                request().uri(),
                "returns_gstr3_generate");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }

    public CompletionStage<Result> returnstatus() {
        String txnid = kafkaProducerService.enqueInKafka(request().headers(),
                request().queryString(),
                null,
                request().uri(),
                "returns_gstr3_retstatus");
        Result result = ok("{\"status_cd\":\"1\",\"" + txnid_type + "\":\"" + txnid + "\"}");
        return CompletableFuture.completedFuture(result);
    }
}
