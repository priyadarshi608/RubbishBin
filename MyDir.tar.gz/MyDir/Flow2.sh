#!/bin/bash
echo "##############################################################################################################################################"
echo "                                                          GST BUYER-SUPPLIER FLOW"
echo "##############################################################################################################################################"
delay=3

sleep $delay

echo "GSTR1 OTP_REQUEST: "
curl -s http://localhost:9000/flow/gstr1_otprequest > rubbish.txt
sleep $delay

echo "GSTR1 AUTHTOKEN: "
curl -s http://localhost:9000/flow/gstr1_authtoken > rubbish.txt
sleep $delay

echo "GSTR2 OTP_REQUEST: "
curl -s http://localhost:9000/flow/gstr2_otprequest > rubbish.txt
sleep $delay

echo "GSTR2 AUTHTOKEN: "
curl -s http://localhost:9000/flow/gstr2_authtoken > rubbish.txt
sleep $delay

echo "GSTR1 SAVE_INVOICES: "
curl -s http://localhost:9000/flow/gstr1_saveinvoices > rubbish.txt
sleep $delay

echo "GSTR1 GET OR B2B: "
curl -s http://localhost:9000/flow/gstr1_get > rubbish.txt
sleep $delay

echo "GSTR2 SAVE_INVOICES: "
curl -s http://localhost:9000/flow/gstr2_saveinvoices > rubbish.txt
sleep $delay

echo "GSTR2 GET OR B2B: "
curl -s http://localhost:9000/flow/gstr2_get > rubbish.txt
sleep $delay

echo "GSTR1 SUBMIT: "
curl -s http://localhost:9000/flow/gstr1_submit > rubbish.txt
sleep $delay

echo "GSTR2 SUBMIT: "
curl -s http://localhost:9000/flow/gstr2_submit > rubbish.txt
sleep $delay

echo "GSTR1A GET: "
curl -s http://localhost:9000/flow/gstr1a_get > rubbish.txt
sleep $delay

echo "GSTR1A SAVE: "
curl -s http://localhost:9000/flow/gstr1a_save > rubbish.txt
sleep $delay

echo "GSTR1A SUBMIT: "
curl -s http://localhost:9000/flow/gstr1a_submit > rubbish.txt
sleep $delay

echo "GSTR3 SUPPLIER GET: "
curl -s http://localhost:9000/flow/gstr3_supplier_get > rubbish.txt
sleep $delay

echo "GSTR3 BUYER GET: "
curl -s http://localhost:9000/flow/gstr3_buyer_get > rubbish.txt
sleep $delay

echo "GSTR3 SUPPLIER SUBMIT: "
curl -s http://localhost:9000/flow/gstr3_supplier_submit > rubbish.txt
sleep $delay

echo "GSTR3 BUYER SUBMIT: "
curl -s http://localhost:9000/flow/gstr3_buyer_submit > rubbish.txt

