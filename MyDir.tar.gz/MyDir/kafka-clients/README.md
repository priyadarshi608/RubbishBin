# kafka-clients
This example shows how to configure various Kafka clients. A blog can be found here https://dzone.com/articles/kafka-clients-at-most-once-at-least-once-exactly-o

