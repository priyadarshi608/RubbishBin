package com.mapr.examples;

import java.io.IOException;

/**
 * Pick whether we want to run as producer or consumer. This lets us
 * have a single executable as a build target.
 */
public class Run {
    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            throw new IllegalArgumentException("Must have either 'producer' or 'consumer' as argument");
        }
        switch (args[0]) {
            case "producer":
            	final int NUMBER_OF_PRODUCERS = 10;
            	Thread[] producerThreads = new Thread[NUMBER_OF_PRODUCERS];
            	for (int i = 0; i < NUMBER_OF_PRODUCERS; i++) {
            		producerThreads[i] = new Thread(new Producer(i));
            	}
        		long producer_start_time = System.currentTimeMillis();
            	for (int i = 0; i < NUMBER_OF_PRODUCERS; i++) {
            		producerThreads[i].start();
            	}
        		for (int i = 0; i < NUMBER_OF_PRODUCERS; i++) {
        			try {
        				producerThreads[i].join();
        			} catch (InterruptedException e) {
        				e.printStackTrace();
        			}
        		}
        		long producer_end_time = System.currentTimeMillis();
        		System.out.println("Threads started at " + producer_start_time);
        		System.out.println("Thread ended at " + producer_end_time);
        		System.out.println("Execution time = " + (producer_end_time - producer_start_time));
                break;
            case "consumer":
            	final int NUMBER_OF_CONSUMERS = 1;
            	Thread[] consumerThreads = new Thread[NUMBER_OF_CONSUMERS];
            	for (int i = 0; i < NUMBER_OF_CONSUMERS; i++) {
            		consumerThreads[i] = new Thread(new Consumer(i));
            	}
        		long consumer_start_time = System.currentTimeMillis();
            	for (int i = 0; i < NUMBER_OF_CONSUMERS; i++) {
            		consumerThreads[i].start();
            	}
        		for (int i = 0; i < NUMBER_OF_CONSUMERS; i++) {
        			try {
        				consumerThreads[i].join();
        			} catch (InterruptedException e) {
        				e.printStackTrace();
        			}
        		}
        		long consumer_end_time = System.currentTimeMillis();
        		System.out.println("Threads started at " + consumer_start_time);
        		System.out.println("Thread ended at " + consumer_end_time);
        		System.out.println("Execution time = " + (consumer_end_time - consumer_start_time - 10000));
                break;
            default:
                throw new IllegalArgumentException("Don't know how to do " + args[0]);
        }
    }
}
