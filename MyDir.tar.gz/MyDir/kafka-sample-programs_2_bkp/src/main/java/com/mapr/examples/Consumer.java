package com.mapr.examples;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;
import org.HdrHistogram.Histogram;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;
import java.util.Random;

/**
 * This program reads messages from two topics. Messages on "fast-messages2" are analyzed
 * to estimate latency (assuming clock synchronization between producer and consumer).
 * Whenever a message is received on "slow-messages", the stats are dumped.
 */
class Consumer implements Runnable {
	private final int consumer_id;
    KafkaProducer<String, String> producer = null;
	
	public Consumer(int id) {
		consumer_id = id;
		
        try (InputStream props = Resources.getResource("producer.props").openStream()) {
            Properties properties = new Properties();
            properties.load(props);
            producer = new KafkaProducer<>(properties);
        } catch (IOException e) {
        	e.printStackTrace();
		}
	}
	
	@Override
    public void run() {
        // ObjectMapper class provides functionalities to convert Java objects to matching 
    	// JSON constructs and vice versa.
        ObjectMapper mapper = new ObjectMapper();
        
        Histogram stats = new Histogram(1, 10000000, 2);
        Histogram global = new Histogram(1, 10000000, 2);

        // and the consumer
        KafkaConsumer<String, String> consumer = null;
        try (InputStream props = Resources.getResource("consumer.props").openStream()) {
            Properties properties = new Properties();
            properties.load(props);
            if (properties.getProperty("group.id") == null) {
                properties.setProperty("group.id", "group-" + new Random().nextInt(100000));
            }
            consumer = new KafkaConsumer<>(properties);
        }
        catch (IOException e) {
        	e.printStackTrace();
		}
        
        consumer.subscribe(Arrays.asList("fast-messages2", "summary-markers2"));
        int timeouts = 0;
        //noinspection InfiniteLoopStatement
        
        int totalCount = 0;
        long recordGettingTime = System.currentTimeMillis();
        boolean haveData = true;
        while (haveData) {
//        	if (consumer_id == 1 || consumer_id == 2)
//        		break;
            // read records with a short timeout. If we time out, we don't really care.
            ConsumerRecords<String, String> records = consumer.poll(10);
            if (records.count() == 0) {
                timeouts++;
            } else {
                System.out.printf("Got %d records after %d timeouts\n", records.count(), timeouts);
                timeouts = 0;
            }
            for (ConsumerRecord<String, String> record : records) {
            	totalCount++;
            	recordGettingTime = System.currentTimeMillis();
//                System.out.println();
//                System.out.println("***************");
//                System.out.println(record.toString());
//                System.out.println("###############");
//                System.out.println();
                switch (record.topic()) {
                    case "fast-messages2":
                        // the send time is encoded inside the message
					JsonNode msg = null;
					try {
						msg = mapper.readTree(record.value());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                        switch (msg.get("type").asText()) {
                            case "test":
                                long latency = (long) ((System.nanoTime() * 1e-9 - msg.get("t").asDouble()) * 1000);
                                stats.recordValue(latency);
                                global.recordValue(latency);
                                break;
                            case "marker":
                                // whenever we get a marker message, we should dump out the stats
                                // note that the number of fast messages won't necessarily be quite constant
                            	System.out.println();
                            	System.out.println("ConsumerID: " + consumer_id);
                                System.out.printf("%d messages received in period, latency(min, max, avg) = %d, %d, %.1f (ms)\n",
                                        stats.getTotalCount(),
                                        stats.getValueAtPercentile(0), stats.getValueAtPercentile(100),
                                        stats.getMean());
                                System.out.printf("%d messages received overall, latency(min, max, avg) = %d, %d, %.1f (ms)\n",
                                        global.getTotalCount(),
                                        global.getValueAtPercentile(0), global.getValueAtPercentile(100),
                                        global.getMean());

                                stats.reset();
                                break;
                            default:
                                throw new IllegalArgumentException("Illegal message type: " + msg.get("type"));
                        }
                        break;
                    case "summary-markers2":
                        break;
                    default:
                        throw new IllegalStateException("Shouldn't be possible to get message on topic " + record.topic());
                }
            }
            long recordProcessedTime = System.currentTimeMillis();
            if ((recordProcessedTime - recordGettingTime) >= 10000) {
//            	System.out.println(recordGettingTime);
//            	System.out.println(recordProcessedTime);
            	haveData = false;
            }
            consumer.commitSync();
        }
    	System.out.println();
        System.out.println("***********************************************");
    	System.out.println("ConsumerID: " + consumer_id);
        System.out.println("Total count: " + totalCount);
        System.out.println("###############################################");
    }
}
