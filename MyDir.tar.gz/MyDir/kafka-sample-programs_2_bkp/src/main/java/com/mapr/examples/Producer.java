package com.mapr.examples;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.google.common.io.Resources;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;

/**
 * This producer will send a bunch of messages to topic "fast-messages2". Every so often,
 * it will send a message to "slow-messages". This shows how messages can be sent to
 * multiple topics. On the receiving end, we will see both kinds of messages but will
 * also see how the two topics aren't really synchronized.
 */
class Producer implements Runnable {
	private final int producer_id;
	
	public Producer(int id) {
		producer_id = id;
	}
	
	@Override
    public void run() {
        // set up the producer
        KafkaProducer<String, String> producer = null;
        try (InputStream props = Resources.getResource("producer.props").openStream()) {
            Properties properties = new Properties();
            properties.load(props);
            producer = new KafkaProducer<>(properties);
        } catch (IOException e) {
        	e.printStackTrace();
		}

        String data = null;
		String five_mb = null;
		String two_mb = null;
		String one_mb = null;
		String five_hundred_kb = null;
		String hundred_kb = null;
		String twenty_kb = null;
		String ten_kb = null;
        try {
			five_mb = readFile("/home/shubham/workspace/myData/5MB");
			two_mb = readFile("/home/shubham/workspace/myData/2MB");
			one_mb = readFile("/home/shubham/workspace/myData/1MB");
			five_hundred_kb = readFile("/home/shubham/workspace/myData/0.5MB");
			hundred_kb = readFile("/home/shubham/workspace/myData/0.1MB");
			twenty_kb = readFile("/home/shubham/workspace/myData/0.02MB");
			ten_kb = readFile("/home/shubham/workspace/myData/0.01MB");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
            for (int i = 1; i <= 1000; i++) {
            	int data_decider = i % 100;
//            	data = five_hundred_kb;
            	if (data_decider>=0 && data_decider<= 1) {
            		data = five_mb;
            	} else if (data_decider>= 2 && data_decider<= 6) {
            		data = two_mb;
            	} else if (data_decider>= 8 && data_decider<= 16) {
            		data = one_mb;
            	} else if (data_decider>= 18 && data_decider<= 36) {
            		data = five_hundred_kb;
            	} else if (data_decider>= 38 && data_decider<= 66) {
            		data = hundred_kb;
            	} else if (data_decider>= 68 && data_decider<= 99) {
            		data = twenty_kb;
            	}
            	int final_i = producer_id * 10000 + i;
//            	int final_i = i;
                // send lots of messages
                producer.send(new ProducerRecord<String, String>(
                        "fast-messages2",
                        String.format("{\"type\":\"test\", \"t\":%.3f, \"k\":%d, \"kafka_data\":%s}", System.nanoTime() * 1e-9, final_i, data)));

                // every so often send to a different topic
                if (i % 100 == 0) {
                    producer.send(new ProducerRecord<String, String>(
                            "fast-messages2",
                            String.format("{\"type\":\"marker\", \"t\":%.3f, \"k\":%d, \"kafka_data\":%s}", System.nanoTime() * 1e-9, final_i, data)));
                    producer.send(new ProducerRecord<String, String>(
                            "summary-markers2",
                            String.format("{\"type\":\"other\", \"t\":%.3f, \"k\":%d, \"kafka_data\":%s}", System.nanoTime() * 1e-9, final_i, data)));
                    producer.flush();
                    System.out.println("Sent msg number " + i);
                }
            }
        } catch (Throwable throwable) {
            System.out.printf("%s", throwable.getStackTrace());
        } finally {
            producer.close();
        }

    }
	
	String readFile(String fileName) throws IOException {
		String uid = UUID.randomUUID().toString();
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}
}
