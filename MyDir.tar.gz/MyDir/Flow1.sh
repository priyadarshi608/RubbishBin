#!/bin/bash
echo "##############################################################################################################################################"
echo "                                                          GST BUYER-SUPPLIER FLOW"
echo "##############################################################################################################################################"
read -p "GSTR1 OTP_REQUEST: " var11
curl -s http://localhost:9000/flow/gstr1_otprequest > rubbish.txt

read -p "" var11
read -p "GSTR1 AUTHTOKEN: " var12
curl -s http://localhost:9000/flow/gstr1_authtoken > rubbish.txt

read -p "" var11
read -p "GSTR2 OTP_REQUEST: " var13
curl -s http://localhost:9000/flow/gstr2_otprequest > rubbish.txt

read -p "" var11
read -p "GSTR2 AUTHTOKEN: " var14
curl -s http://localhost:9000/flow/gstr2_authtoken > rubbish.txt

read -p "" var11
read -p "GSTR1 SAVE_INVOICES: " var1
curl -s http://localhost:9000/flow/gstr1_saveinvoices > rubbish.txt

read -p "" var11
read -p "GSTR1 GET OR B2B: " var2
curl -s http://localhost:9000/flow/gstr1_get > rubbish.txt

read -p "" var11
read -p "GSTR2 SAVE_INVOICES: " var2
curl -s http://localhost:9000/flow/gstr2_saveinvoices > rubbish.txt

read -p "" var11
read -p "GSTR2 GET OR B2B: " var2
curl -s http://localhost:9000/flow/gstr2_get > rubbish.txt

read -p "" var11
read -p "GSTR1 SUBMIT: " var3
curl -s http://localhost:9000/flow/gstr1_submit > rubbish.txt

read -p "" var11
read -p "GSTR2 SUBMIT: " var4
curl -s http://localhost:9000/flow/gstr2_submit > rubbish.txt

read -p "" var11
read -p "GSTR1A GET: " var5
curl -s http://localhost:9000/flow/gstr1a_get > rubbish.txt

read -p "" var11
read -p "GSTR1A SAVE: " var5
curl -s http://localhost:9000/flow/gstr1a_save > rubbish.txt

read -p "" var11
read -p "GSTR1A SUBMIT: " var6
curl -s http://localhost:9000/flow/gstr1a_submit > rubbish.txt

read -p "" var11
read -p "GSTR3 SUPPLIER GET: " var7
curl -s http://localhost:9000/flow/gstr3_supplier_get > rubbish.txt

read -p "" var11
read -p "GSTR3 BUYER GET: " var8
curl -s http://localhost:9000/flow/gstr3_buyer_get > rubbish.txt

read -p "" var11
read -p "GSTR3 SUPPLIER SUBMIT: " var9
curl -s http://localhost:9000/flow/gstr3_supplier_submit > rubbish.txt

read -p "" var11
read -p "GSTR3 BUYER SUBMIT: " var10
curl -s http://localhost:9000/flow/gstr3_buyer_submit > rubbish.txt

