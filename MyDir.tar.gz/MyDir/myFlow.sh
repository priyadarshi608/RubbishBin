#!/bin/bash
echo "##############################################################################################################################################"
echo "                                                          GST BUYER-SUPPLIER FLOW"
echo "##############################################################################################################################################"
read -p "GSTR1 OTP_REQUEST: " var11
curl -s http://localhost:9000/flow/gstr1_otprequest > rubbish.txt

read -p "" var11
read -p "GSTR1 AUTHTOKEN: " var12
curl -s http://localhost:9000/flow/gstr1_authtoken > rubbish.txt

read -p "" var11
read -p "GSTR1 SAVE_INVOICES: " var1
curl -s http://localhost:9000/flow/gstr1_saveinvoices > rubbish.txt

read -p "" var11
read -p "GSTR1 GET OR B2B: " var2
curl -s http://localhost:9000/flow/gstr1_get > rubbish.txt

read -p "" var11
read -p "GSTR1 SUBMIT: " var3
curl -s http://localhost:9000/flow/gstr1_submit > rubbish.txt
