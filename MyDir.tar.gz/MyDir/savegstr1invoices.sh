/usr/bin/kafka-topics --zookeeper localhost:2181 --delete --topic savegstr1invoices
/usr/bin/kafka-topics --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic savegstr1invoices
#/usr/bin/kafka-topics --list --zookeeper localhost:2181
