package com.moglix.cassandra_benchmark;

public class MainClass {
	public static void main(String[] args) {
		int numberOfThreads = 10;
		Thread[] threads = new Thread[numberOfThreads + 1];
		for (int i = 1; i <= numberOfThreads; i++) {
			threads[i] = new Thread(new Task(i));
		}
		long start_time = System.currentTimeMillis();
		for (int i = 1; i <= numberOfThreads; i++) {
			threads[i].start();
		}
		for (int i = 1; i <= numberOfThreads; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		long end_time = System.currentTimeMillis();
		System.out.println("Threads started at " + start_time);
		System.out.println("Thread ended at " + end_time);
		System.out.println("Execution time = " + (end_time - start_time));
	}
}
