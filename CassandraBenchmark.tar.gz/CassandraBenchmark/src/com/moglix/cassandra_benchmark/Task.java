package com.moglix.cassandra_benchmark;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.xml.crypto.Data;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.policies.DefaultRetryPolicy;

public class Task implements Runnable {
	int user_token;
	Builder builder;
	Cluster cluster;
	Session session;
    String data = null;
	String five_mb = null;
	String two_mb = null;
	String one_mb = null;
	String five_hundred_kb = null;
	String hundred_kb = null;
	String twenty_kb = null;
	String ten_kb = null;

	public Task(int i) {
		this.user_token = i;
        try {
			five_mb = readFile("/home/shubham/workspace/myData/5MB");
			two_mb = readFile("/home/shubham/workspace/myData/2MB");
			one_mb = readFile("/home/shubham/workspace/myData/1MB");
			five_hundred_kb = readFile("/home/shubham/workspace/myData/0.5MB");
			hundred_kb = readFile("/home/shubham/workspace/myData/0.1MB");
			twenty_kb = readFile("/home/shubham/workspace/myData/0.02MB");
			ten_kb = readFile("/home/shubham/workspace/myData/0.01MB");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		builder = Cluster.builder();
		builder.addContactPoint("127.0.0.1");
		builder.withPort(9042);
		builder.withCredentials("shubham", null);		
		cluster = builder.build();
		session = cluster.connect("benchmark");
		for(int i = 0; i < 1000; i++) {
			int user_id = (user_token * 10000) + i;
			String user_name = "user_" + user_id;
			try {
//				String data = readFile("/home/shubham/workspace/myData/5MB");
            	int data_decider = i % 100;
//            	data = five_hundred_kb;
            	if (data_decider>=0 && data_decider<= 1) {
            		data = five_mb;
            	} else if (data_decider>= 2 && data_decider<= 6) {
            		data = two_mb;
            	} else if (data_decider>= 8 && data_decider<= 16) {
            		data = one_mb;
            	} else if (data_decider>= 18 && data_decider<= 36) {
            		data = five_hundred_kb;
            	} else if (data_decider>= 38 && data_decider<= 66) {
            		data = hundred_kb;
            	} else if (data_decider>= 68 && data_decider<= 99) {
            		data = twenty_kb;
            	}
				insert(user_id, user_name, data);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		cluster.close();
	}

	String readFile(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

	private void insert(int user_id, String user_name, String data) {
		session.execute("INSERT INTO body_data (user_id, user_name, data) VALUES (" + user_id + ", '" + user_name + "', '" + data + "')");
	}
}
