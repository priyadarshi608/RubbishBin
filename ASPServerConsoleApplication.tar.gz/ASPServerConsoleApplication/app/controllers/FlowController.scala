package controllers

import java.io.PrintWriter

import com.google.inject.{Inject, Singleton}
import play.api._
import play.api.libs.json
import play.api.libs.json.{JsValue, Json}
import play.api.libs.ws.WSClient
import play.api.mvc._

import scala.concurrent.{ExecutionContext, Future}
import scala.concurrent.ExecutionContext.Implicits.global

/**
  * Created by shubham on 16/11/16.
  */
class FlowController @Inject()(wSClient: WSClient,
                               configuration: Configuration)(implicit exec: ExecutionContext) extends Controller {
  def gstr1_otprequest = Action {
    val gstr1_otprequest_body_path = "/home/shubham/workspace/asp_test_data/body/1_otprequest_body"
    var source11 = scala.io.Source.fromFile(gstr1_otprequest_body_path)
    val gstr1_otprequest_body = try source11.mkString finally source11.close()
    var gstr1_otprequest_body_json: JsValue = Json.parse(gstr1_otprequest_body)
    delimiter()
    hash_printer()
    println("                                                               GSTR1: OTP_REQUEST")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr1_otprequest_body_json))
    wSClient.url(configuration.getString("asp.returns.auth.otprequest.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/auth/otprequest"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr1_otprequest_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1_authtoken = Action {
    val gstr1_authtoken_body_path = "/home/shubham/workspace/asp_test_data/body/1_authtoken_body"
    var source12 = scala.io.Source.fromFile(gstr1_authtoken_body_path)
    val gstr1_authtoken_body = try source12.mkString finally source12.close()
    var gstr1_authtoken_body_json: JsValue = Json.parse(gstr1_authtoken_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR1: AUTHTOKEN")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr1_authtoken_body_json))
    wSClient.url(configuration.getString("asp.returns.auth.authtoken.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/auth/authtoken"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr1_authtoken_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr2_otprequest = Action {
    val gstr2_otprequest_body_path = "/home/shubham/workspace/asp_test_data/body/2_otprequest_body"
    var source13 = scala.io.Source.fromFile(gstr2_otprequest_body_path)
    val gstr2_otprequest_body = try source13.mkString finally source13.close()
    var gstr2_otprequest_body_json: JsValue = Json.parse(gstr2_otprequest_body)
    delimiter()
    hash_printer()
    println("                                                               GSTR2: OTP_REQUEST")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr2_otprequest_body_json))
    wSClient.url(configuration.getString("asp.returns.auth.otprequest.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/auth/otprequest"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr2_otprequest_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
       response.json
      }
    Ok(views.html.index(""))
  }

  def gstr2_authtoken = Action {
    val gstr2_authtoken_body_path = "/home/shubham/workspace/asp_test_data/body/2_authtoken_body"
    var source14 = scala.io.Source.fromFile(gstr2_authtoken_body_path)
    val gstr2_authtoken_body = try source14.mkString finally source14.close()
    var gstr2_authtoken_body_json: JsValue = Json.parse(gstr2_authtoken_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR2: AUTHTOKEN")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr2_authtoken_body_json))
    wSClient.url(configuration.getString("asp.returns.auth.authtoken.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/auth/authtoken"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr2_authtoken_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1_saveinvoices = Action {
    val gstr1_saveinvoices_body_path = "/home/shubham/workspace/asp_test_data/body/1_saveinvoices_body"
    var source1 = scala.io.Source.fromFile(gstr1_saveinvoices_body_path)
    val gstr1_saveinvoices_body = try source1.mkString finally source1.close()
    var gstr1_saveinvoices_body_json: JsValue = Json.parse(gstr1_saveinvoices_body)
    delimiter()
    hash_printer()
    println("                                                               GSTR1: SAVE_INVOICES")
    request_body_message_delimiter()
//    println(gstr1_saveinvoices_body)
    println(Json.prettyPrint(gstr1_saveinvoices_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr1.retsave.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1/retsave"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .put(gstr1_saveinvoices_body_json)
//      .put(gstr1_saveinvoices_body)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
      Ok(views.html.index(""))
  }

  def gstr1_get = Action {
    delimiter()
    hash_printer()
    println("                                                               GSTR1: GET OR B2B")
    wSClient.url(configuration.getString("asp.returns.gstr1.b2b.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1/b2b"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .withQueryString("ret_period" -> "072016", "action_required" -> "Y", "gstin" -> "04AABFN9870CMZT", "action" -> "B2B")
      .get()
      .map { response =>
      response_body_message_delimiter()
      println(response.json)
      response.json
    }
    Ok(views.html.index(""))
  }

  def gstr2_saveinvoices = Action {
    val gstr2_saveinvoices_body_path = "/home/shubham/workspace/asp_test_data/body/2_saveinvoices_body"
    var source2 = scala.io.Source.fromFile(gstr2_saveinvoices_body_path)
    val gstr2_saveinvoices_body = try source2.mkString finally source2.close()
    var gstr2_saveinvoices_body_json: JsValue = Json.parse(gstr2_saveinvoices_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR2: SAVE_INVOICES")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr2_saveinvoices_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr2.retsave.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr2/retsave"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .put(gstr2_saveinvoices_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr2_get = Action {
    delimiter()
    hash_printer()
    println("                                                                GSTR2: GET OR B2B")
    wSClient.url(configuration.getString("asp.returns.gstr2.b2b.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr2/b2b"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .withQueryString("ret_period" -> "072016", "action_required" -> "Y", "gstin" -> "04AABFN9870CMZT", "action" -> "B2B")
      .get()
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1_submit = Action {
    val gstr1_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/1_file_or_submit_body"
    var source3 = scala.io.Source.fromFile(gstr1_file_or_submit_body_path)
    val gstr1_file_or_submit_body = try source3.mkString finally source3.close()
    var gstr1_file_or_submit_body_json: JsValue = Json.parse(gstr1_file_or_submit_body)
    delimiter()
    hash_printer()
    println("                                                                  GSTR1: SUBMIT")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr1_file_or_submit_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr1.submit.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr1_file_or_submit_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr2_submit = Action {
    val gstr2_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/2_file_or_submit_body"
    var source4 = scala.io.Source.fromFile(gstr2_file_or_submit_body_path)
    val gstr2_file_or_submit_body = try source4.mkString finally source4.close()
    var gstr2_file_or_submit_body_json: JsValue = Json.parse(gstr2_file_or_submit_body)
    delimiter()
    hash_printer()
    println("                                                                  GSTR2: SUBMIT")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr2_file_or_submit_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr2.submit.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr2/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr2_file_or_submit_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1a_get = Action {
    delimiter()
    hash_printer()
    println("                                                                    GSTR1a: GET OR B2B")
    wSClient.url(configuration.getString("asp.returns.gstr1a.b2b.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1a/b2b"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .withQueryString("ret_period" -> "072016", "action_required" -> "Y", "gstin" -> "04AABFN9870CMZT", "action" -> "B2B")
      .get()
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1a_save = Action {
    val gstr1a_saveinvoices_body_path = "/home/shubham/workspace/asp_test_data/body/1a_saveinvoices_body"
    var source5 = scala.io.Source.fromFile(gstr1a_saveinvoices_body_path)
    val gstr1a_saveinvoices_body = try source5.mkString finally source5.close()
    var gstr1a_saveinvoices_body_json: JsValue = Json.parse(gstr1a_saveinvoices_body)
    delimiter()
    hash_printer()
    println("                                                                   GSTR1a: SAVE")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr1a_saveinvoices_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr1a.retsave.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1a/retsave"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .put(gstr1a_saveinvoices_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr1a_submit = Action {
    val gstr1a_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/1a_file_or_submit_body"
    var source5 = scala.io.Source.fromFile(gstr1a_file_or_submit_body_path)
    val gstr1a_file_or_submit_body = try source5.mkString finally source5.close()
    var gstr1a_file_or_submit_body_json: JsValue = Json.parse(gstr1a_file_or_submit_body)
    delimiter()
    hash_printer()
    println("                                                                  GSTR1a: SUBMIT")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr1a_file_or_submit_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr1a.submit.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr1a/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr1a_file_or_submit_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr3_supplier_get = Action {
    val gstr3_supplier_generate_body_path = "/home/shubham/workspace/asp_test_data/body/3_supplier_generate_body"
    var source6 = scala.io.Source.fromFile(gstr3_supplier_generate_body_path)
    val gstr3_supplier_generate_body = try source6.mkString finally source6.close()
    var gstr3_supplier_generate_body_json: JsValue = Json.parse(gstr3_supplier_generate_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR3: SUPPLIER_GET")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr3_supplier_generate_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr3.generate.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr3/generate"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr3_supplier_generate_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr3_buyer_get = Action {
    val gstr3_buyer_generate_body_path = "/home/shubham/workspace/asp_test_data/body/3_buyer_generate_body"
    var source7 = scala.io.Source.fromFile(gstr3_buyer_generate_body_path)
    val gstr3_buyer_generate_body = try source7.mkString finally source7.close()
    var gstr3_buyer_generate_body_json: JsValue = Json.parse(gstr3_buyer_generate_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR3: BUYER_GET")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr3_buyer_generate_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr3.generate.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr3/generate"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr3_buyer_generate_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr3_supplier_submit = Action {
    val gstr3_supplier_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/3_supplier_file_or_submit_body"
    var source8 = scala.io.Source.fromFile(gstr3_supplier_file_or_submit_body_path)
    val gstr3_supplier_file_or_submit_body = try source8.mkString finally source8.close()
    var gstr3_supplier_file_or_submit_body_json: JsValue = Json.parse(gstr3_supplier_file_or_submit_body)
    delimiter()
    hash_printer()
    println("                                                              GSTR3: SUPPLIER_SUBMIT")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr3_supplier_file_or_submit_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr3.file_or_submit.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr3/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr3_supplier_file_or_submit_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }

  def gstr3_buyer_submit = Action {
    val gstr3_buyer_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/3_buyer_file_or_submit_body"
    var source9 = scala.io.Source.fromFile(gstr3_buyer_file_or_submit_body_path)
    val gstr3_buyer_file_or_submit_body = try source9.mkString finally source9.close()
    var gstr3_buyer_file_or_submit_body_json: JsValue = Json.parse(gstr3_buyer_file_or_submit_body)
    delimiter()
    hash_printer()
    println("                                                                GSTR3: BUYER_SUBMIT")
    request_body_message_delimiter()
    println(Json.prettyPrint(gstr3_buyer_file_or_submit_body_json))
    wSClient.url(configuration.getString("asp.returns.gstr3.file_or_submit.uri").getOrElse("http://aspapi.smartgsp.com/aspapi/v1.0/returns/gstr3/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ip-usr" -> "12.8.9l.80")
      .post(gstr3_buyer_file_or_submit_body_json)
      .map { response =>
        response_body_message_delimiter()
        println(response.json)
        response.json
      }
    Ok(views.html.index(""))
  }
  
  def delimiter(): Unit = {
    println()
    println()
    println()
    println()
    println()
    println()
    println()
    println()
    println()
    println()
  }
  
  def request_body_message_delimiter() {
    hash_printer()
    println("The request body is:")
    println()
  }

  def response_body_message_delimiter(): Unit = {
    println()
    println()
    dollar_printer()
    println("The response is:")
    println()
  }

  def hash_printer(): Unit = {
    println("###############################################################################################################################################")
  }

  def dollar_printer(): Unit = {
    println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
  }
}
