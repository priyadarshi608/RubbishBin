package controllers

import java.io.PrintWriter

import com.google.inject.{Inject, Singleton}
import play.api._
import play.api.libs.json
import play.api.libs.json.{JsValue, Json}
import play.api.libs.ws.WSClient
import play.api.mvc._

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(wSClient: WSClient,
                               configuration: Configuration) extends Controller {

  def index = Action{

    val gstr1_saveinvoices_body_path = "/home/shubham/workspace/asp_test_data/body/1_saveinvoices_body"
    var source1 = scala.io.Source.fromFile(gstr1_saveinvoices_body_path)
    val gstr1_saveinvoices_body = try source1.mkString finally source1.close()
    var gstr1_saveinvoices_body_json: JsValue = Json.parse(gstr1_saveinvoices_body)
//    println(gstr1_saveinvoices_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr1.retsave.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr1/retsave"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .put(gstr1_saveinvoices_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr1_saveinvoices") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr2_saveinvoices_body_path = "/home/shubham/workspace/asp_test_data/body/2_saveinvoices_body"
    var source2 = scala.io.Source.fromFile(gstr2_saveinvoices_body_path)
    val gstr2_saveinvoices_body = try source2.mkString finally source2.close()
    var gstr2_saveinvoices_body_json: JsValue = Json.parse(gstr2_saveinvoices_body)
//    println(gstr2_saveinvoices_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr2.retsave.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr2/retsave"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .put(gstr2_saveinvoices_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr2_saveinvoices") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr1_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/1_file_or_submit_body"
    var source3 = scala.io.Source.fromFile(gstr1_file_or_submit_body_path)
    val gstr1_file_or_submit_body = try source3.mkString finally source3.close()
    var gstr1_file_or_submit_body_json: JsValue = Json.parse(gstr1_file_or_submit_body)
//    println(gstr1_file_or_submit_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr1.submit.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr1/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr1_file_or_submit_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr1_submit") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr2_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/2_file_or_submit_body"
    var source4 = scala.io.Source.fromFile(gstr2_file_or_submit_body_path)
    val gstr2_file_or_submit_body = try source4.mkString finally source4.close()
    var gstr2_file_or_submit_body_json: JsValue = Json.parse(gstr2_file_or_submit_body)
//    println(gstr2_file_or_submit_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr2.submit.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr2/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr2_file_or_submit_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr2_submit") {
          write(response.json.toString());
          close
        }
        response.json
      }

    wSClient.url(configuration.getString("asp.returns.gstr1a.b2b.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr1a/b2b"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .get()
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr1a_b2b") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr1a_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/1a_file_or_submit_body"
    var source5 = scala.io.Source.fromFile(gstr1a_file_or_submit_body_path)
    val gstr1a_file_or_submit_body = try source5.mkString finally source5.close()
    var gstr1a_file_or_submit_body_json: JsValue = Json.parse(gstr1a_file_or_submit_body)
//    println(gstr1a_file_or_submit_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr1a.submit.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr1a/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr1a_file_or_submit_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr1a_submit") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr3_supplier_generate_body_path = "/home/shubham/workspace/asp_test_data/body/3_supplier_generate_body"
    var source6 = scala.io.Source.fromFile(gstr3_supplier_generate_body_path)
    val gstr3_supplier_generate_body = try source6.mkString finally source6.close()
    var gstr3_supplier_generate_body_json: JsValue = Json.parse(gstr3_supplier_generate_body)
    println(gstr3_supplier_generate_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr3.generate.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/generate"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr3_supplier_generate_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_supplier_generate") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr3_buyer_generate_body_path = "/home/shubham/workspace/asp_test_data/body/3_buyer_generate_body"
    var source7 = scala.io.Source.fromFile(gstr3_buyer_generate_body_path)
    val gstr3_buyer_generate_body = try source7.mkString finally source7.close()
    var gstr3_buyer_generate_body_json: JsValue = Json.parse(gstr3_buyer_generate_body)
    println(gstr3_buyer_generate_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr3.generate.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/generate"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr3_buyer_generate_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_buyer_generate") {
          write(response.json.toString());
          close
        }
        response.json
      }

/*    wSClient.url(configuration.getString("asp.returns.gstr3.returndetail.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/retdet"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .get()
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_supplier_returndetail") {
          write(response.json.toString());
          close
        }
        response.json
      }

    wSClient.url(configuration.getString("asp.returns.gstr3.returndetail.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/retdet"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .get()
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_buyer_returndetail") {
          write(response.json.toString());
          close
        }
        response.json
      }*/

    val gstr3_supplier_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/3_supplier_file_or_submit_body"
    var source8 = scala.io.Source.fromFile(gstr3_supplier_file_or_submit_body_path)
    val gstr3_supplier_file_or_submit_body = try source8.mkString finally source8.close()
    var gstr3_supplier_file_or_submit_body_json: JsValue = Json.parse(gstr3_supplier_file_or_submit_body)
    println(gstr3_supplier_file_or_submit_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr3.file_or_submit.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "Moglix_VP", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr3_supplier_file_or_submit_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_supplier_submit") {
          write(response.json.toString());
          close
        }
        response.json
      }

    val gstr3_buyer_file_or_submit_body_path = "/home/shubham/workspace/asp_test_data/body/3_buyer_file_or_submit_body"
    var source9 = scala.io.Source.fromFile(gstr3_buyer_file_or_submit_body_path)
    val gstr3_buyer_file_or_submit_body = try source9.mkString finally source9.close()
    var gstr3_buyer_file_or_submit_body_json: JsValue = Json.parse(gstr3_buyer_file_or_submit_body)
    println(gstr3_buyer_file_or_submit_body_json)
    wSClient.url(configuration.getString("asp.returns.gstr3.file_or_submit.uri").getOrElse("http://localhost:8888/aspapi/v1.0/returns/gstr3/retsubmit"))
      .withHeaders("Content-Type" -> "application/json", "username" -> "moglix_bp", "userrole" -> "superadmin", "ipuser" -> "12.8.9l.80")
      .post(gstr3_buyer_file_or_submit_body_json)
      .map { response =>
        Logger.info(response.json.toString())
        new PrintWriter("/home/shubham/workspace/asp_test_data/response/gstr3_buyer_submit") {
          write(response.json.toString());
          close
        }
        response.json
      }

    Ok(views.html.index("Your new application is ready."))
  }

}
