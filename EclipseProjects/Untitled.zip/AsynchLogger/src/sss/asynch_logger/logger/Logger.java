package sss.asynch_logger.logger;

/**
 * Logger Interface
 * 
 * @author shubham
 */
public interface Logger {
	void logMessage(String message);
}
