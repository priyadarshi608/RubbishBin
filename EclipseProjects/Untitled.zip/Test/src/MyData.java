public class MyData {
	static volatile int i;
}
