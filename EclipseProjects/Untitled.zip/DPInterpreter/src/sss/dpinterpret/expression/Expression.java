package sss.dpinterpret.expression;

public interface Expression {
	public boolean interpret(String context);
}
