import java.lang.annotation.Documented;

@Documented
public @interface Test_Documented {
   String doTestDocument();
}
