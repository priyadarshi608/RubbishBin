package sss.dpiterator_1.container;

public interface Iterator {
	public boolean hasNext();
	public Object next();
}
