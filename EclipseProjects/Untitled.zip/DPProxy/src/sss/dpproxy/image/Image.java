package sss.dpproxy.image;

public interface Image {
	void display();
}
