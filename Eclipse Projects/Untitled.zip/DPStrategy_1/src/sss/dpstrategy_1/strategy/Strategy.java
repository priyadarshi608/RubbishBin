package sss.dpstrategy_1.strategy;

public interface Strategy {
	public int doOperation(int num1, int num2);
}
