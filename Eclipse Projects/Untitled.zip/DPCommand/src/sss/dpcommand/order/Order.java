package sss.dpcommand.order;

public interface Order {
	void execute();
}
